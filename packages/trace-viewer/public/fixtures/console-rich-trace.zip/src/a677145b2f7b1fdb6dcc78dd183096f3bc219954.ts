
import { expect, test } from '@playwright/test'

test('rich console output', async ({ page }) => {
  await page.setContent('<button id="run">Run console</button><output id="done"></output><script>document.getElementById("run").addEventListener("click",()=>{console.log("checkout state",{step:"payment",total:29});console.info("info message",["trace","viewer"]);console.warn("payment latency warning");console.error("payment failed",{code:"card_declined"});document.getElementById("done").textContent="console complete"})<\/script>', { baseURL: 'https://demo.kinora.dev' })
  await page.getByRole('button', { name: 'Run console' }).click()
  await expect(page.locator('#done')).toHaveText('console complete')
})
