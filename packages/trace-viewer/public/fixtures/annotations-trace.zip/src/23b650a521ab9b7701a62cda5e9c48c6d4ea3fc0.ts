
import { expect, test } from '@playwright/test'

test('annotation metadata support', async ({ page }, testInfo) => {
  testInfo.annotations.push({ type: 'issue', description: 'https://kinora.dev/docs/trace-viewer' })
  testInfo.annotations.push({ type: 'owner', description: 'QA platform team' })
  await page.setContent('<main><h1>Annotated trace</h1><p>Custom annotations are visible in the viewer.</p></main>')
  await expect(page.getByRole('heading', { name: 'Annotated trace' })).toBeVisible()
})
