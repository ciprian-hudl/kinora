
import { expect, test } from '@playwright/test'

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/l5Ta2QAAAABJRU5ErkJggg==', 'base64')

test('checkout flow demo', async ({ page }, testInfo) => {
  await page.route('**/style.css', route => route.fulfill({
    contentType: 'text/css',
    body: `body{font-family:system-ui;margin:40px;background:#0f172a;color:#e2e8f0}
      .card{background:#1e293b;padding:24px;border-radius:12px;max-width:520px;box-shadow:0 10px 40px rgba(0,0,0,.4)}
      h1{margin:0 0 8px;color:#f59e0b} button{background:#f59e0b;color:#000;border:0;padding:10px 16px;border-radius:8px;font-weight:600;cursor:pointer}
      input{padding:8px;border-radius:6px;border:1px solid #334155;background:#0f172a;color:#fff;margin-right:8px}`,
  }))
  await page.route('**/logo.png', route => route.fulfill({ contentType: 'image/png', body: PNG }))

  await page.setContent(`<!doctype html><html><head>
    <link rel="stylesheet" href="https://demo.kinora.dev/style.css">
    </head><body>
    <div class="card">
      <img src="https://demo.kinora.dev/logo.png" width="32" height="32" alt="Kinora logo">
      <h1 id="title">Checkout flow</h1>
      <p>Sample page for the Kinora trace viewer.</p>
      <input id="customer" placeholder="customer name">
      <button id="complete">Complete order</button>
    </div>
    <script>
      document.getElementById('complete').addEventListener('click', () => {
        console.log('order submitted, customer =', document.getElementById('customer').value);
        console.warn('demo warning from checkout flow');
        document.getElementById('title').textContent = 'Order complete';
      });
    </script>
  </body></html>`, { baseURL: 'https://demo.kinora.dev' })

  await page.fill('#customer', 'Alex')
  await page.click('#complete')
  await expect(page.locator('#title')).toHaveText('Order complete')

  await testInfo.attach('screenshot', { body: await page.screenshot(), contentType: 'image/png' })
  await testInfo.attach('note', { body: 'Demo trace generated for Kinora', contentType: 'text/plain' })
})
